import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTripContext } from "@/lib/trip-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format, differenceInDays, addDays } from "date-fns";
import { vi } from "date-fns/locale";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";

interface Attraction {
  id: number;
  name: string;
  location_id: number;
  description: string;
  price: number;
  duration: string;
  image_url: string;
  is_recommended: boolean;
}

const bookingFormSchema = z.object({
  fullName: z.string().min(2, { message: "Họ tên phải có ít nhất 2 ký tự" }),
  email: z.string().email({ message: "Email không hợp lệ" }),
  phone: z.string().min(10, { message: "Số điện thoại không hợp lệ" }),
  address: z.string().optional(),
  specialRequests: z.string().optional(),
  buyInsurance: z.boolean().default(false),
  buySim: z.boolean().default(false),
  needGuide: z.boolean().default(false),
  insuranceQuantity: z.number().default(0),
  simQuantity: z.number().default(0),
  guideQuantity: z.number().default(0),
});

type BookingFormValues = z.infer<typeof bookingFormSchema>;

export default function StepFour() {
  const { tripData, updateTripData, setCurrentStep } = useTripContext();
  const basePrice = Number(tripData.totalPrice) || 0;
  const adults = tripData.adults || 1;
  const children = tripData.children || 0;
  const totalPeople = adults + children;

  const [additionalServices, setAdditionalServices] = useState<{
    insurance: number;
    sim: number;
    guide: number;
  }>({
    insurance: 0,
    sim: 0,
    guide: 0,
  });

  const [insuranceQuantity, setInsuranceQuantity] = useState<number>(totalPeople);
  const [simQuantity, setSimQuantity] = useState<number>(adults);
  const [guideQuantity, setGuideQuantity] = useState<number>(1);
  const [finalTotal, setFinalTotal] = useState<number>(0);

  const { data: originLocation } = useQuery({
    queryKey: [`/api/locations/${tripData.origin_id}`],
    enabled: !!tripData.origin_id,
  });
  const { data: destinationLocation } = useQuery({
    queryKey: [`/api/locations/${tripData.destination_id}`],
    enabled: !!tripData.destination_id,
  });

  const { data: transportationSummary } = useQuery({
    queryKey: [
      `/api/transportation-options?originId=${tripData.origin_id}&destinationId=${tripData.destination_id}`,
    ],
    enabled: !!(
      tripData.origin_id &&
      tripData.destination_id &&
      tripData.selectedDepartureOption &&
      tripData.selectedReturnOption
    ),
    select: (data) => {
      const originalDepId = Math.floor(tripData.selectedDepartureOption / 100);
      const originalRetId = Math.floor(tripData.selectedReturnOption / 100);
      const depOption = data.find((option: any) => option.id === originalDepId);
      const retOption = data.find((option: any) => option.id === originalRetId);
      return { depOption, retOption };
    },
  });

  const { data: accommodationsSummary } = useQuery({
    queryKey: ["accommodationsSummary", tripData.accommodations?.map((a) => a.location)],
    queryFn: async () => {
      const results = await Promise.all(
        (tripData.accommodations || []).map((accom) =>
          fetch(`/api/accommodations?locationId=${accom.location}`).then((res) => res.json())
        )
      );
      const selectedAccomIds = tripData.selectedAccommodations
        ? Object.values(tripData.selectedAccommodations)
        : [];
      return results
        .flat()
        .filter((accom: any) => selectedAccomIds.includes(accom.id))
        .map((accom: any) => {
          const tripAccom = tripData.accommodations.find(
            (a) => tripData.selectedAccommodations[a.id] === accom.id
          );
          return { ...accom, checkIn: tripAccom?.checkIn, checkOut: tripAccom?.checkOut };
        });
    },
    enabled: !!tripData.accommodations && tripData.accommodations.length > 0,
  });

  const { data: attractions, isLoading: isLoadingAttractions } = useQuery<Attraction[]>({
    queryKey: ["attractions", tripData.accommodations?.map((a) => a.location)],
    queryFn: async () => {
      const uniqueLocationIds = [...new Set(tripData.accommodations?.map((a) => a.location))];
      const results = await Promise.all(
        uniqueLocationIds.map((locationId) =>
          fetch(`/api/attractions?locationId=${locationId}`).then((res) => res.json())
        )
      );
      const flattenedResults = results
        .map((result) => {
          if (Array.isArray(result)) return result;
          if (result && Array.isArray(result.data)) return result.data;
          console.warn("Unexpected API response format for attractions:", result);
          return [];
        })
        .flat();
      const selectedAttractionIds = tripData.selectedAttractions?.map((item: any) => item.attractionId) || [];
      return flattenedResults.filter((attr: Attraction) =>
        selectedAttractionIds.includes(attr.id)
      );
    },
    enabled: !!tripData.accommodations && tripData.accommodations.length > 0,
  });

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      address: "",
      specialRequests: "",
      buyInsurance: false,
      buySim: false,
      needGuide: false,
      insuranceQuantity: totalPeople,
      simQuantity: adults,
      guideQuantity: 1,
    },
  });

  const calculateAttractionTotal = () => {
    console.log("attractions:", attractions);
    console.log("selectedAttractions:", tripData.selectedAttractions);

    if (!Array.isArray(attractions) || !Array.isArray(tripData.selectedAttractions) || tripData.selectedAttractions.length === 0) {
      console.warn("Invalid attractions or selectedAttractions data");
      return 0;
    }

    return tripData.selectedAttractions.reduce((sum: number, selected: any) => {
      const attraction = attractions.find((attr: Attraction) => attr.id === selected.attractionId);
      if (!attraction) {
        console.warn(`Attraction with ID ${selected.attractionId} not found`);
        return sum;
      }

      const adultPrice = Number(attraction.price) * (selected.adults || 0);
      let childPrice = 0;
      if (selected.childrenHeights && Array.isArray(selected.childrenHeights)) {
        selected.childrenHeights.forEach((height: string) => {
          if (height === "<1m") childPrice += 0;
          else if (height === "1-1m3") childPrice += Number(attraction.price) * 0.5;
          else if (height === ">1m3") childPrice += Number(attraction.price);
        });
      } else {
        console.warn(`Invalid childrenHeights for attraction ${selected.attractionId}`);
      }

      const totalForAttraction = adultPrice + childPrice;
      console.log(`Attraction ${attraction.name}: ${totalForAttraction}đ (Adults: ${adultPrice}, Children: ${childPrice})`);
      return sum + totalForAttraction;
    }, 0);
  };

  useEffect(() => {
    const attractionTotal = calculateAttractionTotal();
    const servicesTotal =
      additionalServices.insurance + additionalServices.sim + additionalServices.guide;
    const newFinalTotal = basePrice + attractionTotal + servicesTotal;
    console.log("Final Total:", newFinalTotal, { basePrice, attractionTotal, servicesTotal });
    setFinalTotal(newFinalTotal);
  }, [basePrice, attractions, additionalServices, tripData.selectedAttractions]);

  const formatDate = (date: Date | string) => format(new Date(date), "dd/MM/yyyy", { locale: vi });

  const getTripDuration = () => {
    if (tripData.start_date && tripData.end_date) {
      const start = new Date(tripData.start_date);
      const end = new Date(tripData.end_date);
      return differenceInDays(end, start) + 1;
    }
    return 0;
  };

  const getTripDays = () => {
    if (tripData.start_date && tripData.end_date) {
      const start = new Date(tripData.start_date);
      const end = new Date(tripData.end_date);
      const dayCount = differenceInDays(end, start) + 1;
      const daysArray: Date[] = [];
      for (let i = 0; i < dayCount; i++) {
        daysArray.push(addDays(start, i));
      }
      return daysArray;
    }
    return [];
  };

  const updateServicePrice = () => {
    const tripDuration = getTripDuration();
    const insurancePrice = form.getValues("buyInsurance") ? insuranceQuantity * 120000 : 0;
    const simPrice = form.getValues("buySim") ? simQuantity * 100000 : 0;
    const guidePrice = form.getValues("needGuide") ? guideQuantity * 1500000 * tripDuration : 0;

    setAdditionalServices({
      insurance: insurancePrice,
      sim: simPrice,
      guide: guidePrice,
    });
  };

  const handleQuantityChange = (service: string, delta: number) => {
    if (service === "insurance") {
      const newQuantity = Math.max(0, insuranceQuantity + delta);
      setInsuranceQuantity(newQuantity);
      form.setValue("insuranceQuantity", newQuantity);
    } else if (service === "sim") {
      const newQuantity = Math.max(0, simQuantity + delta);
      setSimQuantity(newQuantity);
      form.setValue("simQuantity", newQuantity);
    } else if (service === "guide") {
      const newQuantity = Math.max(0, guideQuantity + delta);
      setGuideQuantity(newQuantity);
      form.setValue("guideQuantity", newQuantity);
    }
    updateServicePrice();
  };

  const onServiceToggle = (service: string, checked: boolean) => {
    if (service === "insurance") form.setValue("buyInsurance", checked);
    else if (service === "sim") form.setValue("buySim", checked);
    else if (service === "guide") form.setValue("needGuide", checked);
    updateServicePrice();
  };

  const onSubmit = (data: BookingFormValues) => {
    updateTripData({
      totalPrice: finalTotal,
      bookingInfo: data,
    });
    setCurrentStep(5);
  };

  const handleBack = () => setCurrentStep(3);

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
      <div className="p-8">
        <h2 className="font-bold text-2xl mb-6 border-b pb-3 border-gray-200">
          Bước 4: Xác nhận thông tin & Dịch vụ bổ sung
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="border border-gray-200 shadow-sm">
              <CardHeader>
                <CardTitle className="text-xl font-semibold">Thông tin người đặt</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <FormField
                        control={form.control}
                        name="fullName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Họ và tên</FormLabel>
                            <FormControl>
                              <Input placeholder="Nhập họ và tên" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Số điện thoại</FormLabel>
                            <FormControl>
                              <Input placeholder="Nhập số điện thoại" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Nhập email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Địa chỉ</FormLabel>
                          <FormControl>
                            <Input placeholder="Nhập địa chỉ" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="specialRequests"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Yêu cầu đặc biệt</FormLabel>
                          <FormControl>
                            <Input placeholder="Nhập yêu cầu (nếu có)" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <h3 className="font-semibold text-lg pt-3">Dịch vụ bổ sung</h3>
                    <div className="space-y-3">
                      <FormField
                        control={form.control}
                        name="buyInsurance"
                        render={({ field }) => (
                          <FormItem className="flex items-center space-x-4 p-4 border rounded-lg">
                            <FormControl>
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={(e) => {
                                  field.onChange(e.target.checked);
                                  onServiceToggle("insurance", e.target.checked);
                                }}
                              />
                            </FormControl>
                            <div className="flex-1">
                              <p className="font-medium">Bảo hiểm du lịch</p>
                              <p className="text-sm text-gray-600">120.000₫/người</p>
                            </div>
                            {field.value && (
                              <div className="flex items-center space-x-2">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange("insurance", -1)}
                                >
                                  -
                                </Button>
                                <span className="text-sm">{insuranceQuantity}</span>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange("insurance", 1)}
                                >
                                  +
                                </Button>
                              </div>
                            )}
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="buySim"
                        render={({ field }) => (
                          <FormItem className="flex items-center space-x-4 p-4 border rounded-lg">
                            <FormControl>
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={(e) => {
                                  field.onChange(e.target.checked);
                                  onServiceToggle("sim", e.target.checked);
                                }}
                              />
                            </FormControl>
                            <div className="flex-1">
                              <p className="font-medium">Sim 4G data (không giới hạn)</p>
                              <p className="text-sm text-gray-600">100.000₫/sim</p>
                            </div>
                            {field.value && (
                              <div className="flex items-center space-x-2">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange("sim", -1)}
                                >
                                  -
                                </Button>
                                <span className="text-sm">{simQuantity}</span>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange("sim", 1)}
                                >
                                  +
                                </Button>
                              </div>
                            )}
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="needGuide"
                        render={({ field }) => (
                          <FormItem className="flex items-center space-x-4 p-4 border rounded-lg">
                            <FormControl>
                              <input
                                type="checkbox"
                                checked={field.value}
                                onChange={(e) => {
                                  field.onChange(e.target.checked);
                                  onServiceToggle("guide", e.target.checked);
                                }}
                              />
                            </FormControl>
                            <div className="flex-1">
                              <p className="font-medium">Hướng dẫn viên</p>
                              <p className="text-sm text-gray-600">1.500.000₫/ngày/hướng dẫn viên</p>
                            </div>
                            {field.value && (
                              <div className="flex items-center space-x-2">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange("guide", -1)}
                                >
                                  -
                                </Button>
                                <span className="text-sm">{guideQuantity}</span>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange("guide", 1)}
                                >
                                  +
                                </Button>
                              </div>
                            )}
                          </FormItem>
                        )}
                      />
                    </div>
                    <button type="submit" className="hidden">Submit</button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <Card className="border border-gray-200 shadow-sm">
              <CardHeader className="bg-gray-50 p-4">
                <CardTitle className="text-xl font-bold">Tóm tắt chuyến đi</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold text-gray-700">Thông tin chuyến đi</h3>
                  <div className="grid grid-cols-2 gap-y-2">
                    <span className="text-sm text-gray-600">Hành trình:</span>
                    <span className="text-sm font-medium text-gray-800">
                      {originLocation?.name || "Chưa tải"} - {destinationLocation?.name || "Chưa tải"}
                    </span>
                    <span className="text-sm text-gray-600">Ngày đi:</span>
                    <span className="text-sm font-medium text-gray-800">
                      {tripData.start_date ? formatDate(tripData.start_date) : "Chưa xác định"}
                    </span>
                    <span className="text-sm text-gray-600">Ngày về:</span>
                    <span className="text-sm font-medium text-gray-800">
                      {tripData.end_date ? formatDate(tripData.end_date) : "Chưa xác định"}
                    </span>
                    <span className="text-sm text-gray-600">Số ngày:</span>
                    <span className="text-sm font-medium text-gray-800">
                      {getTripDuration()} ngày
                    </span>
                    <span className="text-sm text-gray-600">Hành khách:</span>
                    <span className="text-sm font-medium text-gray-800">
                      {tripData.adults} NL, {tripData.children} TE
                    </span>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">Chi phí</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-base text-gray-600">Di chuyển + Lưu trú:</span>
                      <span className="text-base font-medium text-gray-800">
                        {basePrice.toLocaleString()}₫
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-base text-gray-600">Điểm tham quan:</span>
                      {isLoadingAttractions ? (
                        <span className="text-base font-medium text-gray-500">Đang tải...</span>
                      ) : tripData.selectedAttractions && tripData.selectedAttractions.length > 0 ? (
                        <span className="text-base font-medium text-gray-800">
                          {calculateAttractionTotal().toLocaleString()}₫
                        </span>
                      ) : (
                        <span className="text-base font-medium text-gray-500">Chưa chọn</span>
                      )}
                    </div>
                    {additionalServices.insurance > 0 && (
                      <div className="flex justify-between">
                        <span className="text-base text-gray-600">Bảo hiểm:</span>
                        <span className="text-base font-medium text-gray-800">
                          {additionalServices.insurance.toLocaleString()}₫
                        </span>
                      </div>
                    )}
                    {additionalServices.sim > 0 && (
                      <div className="flex justify-between">
                        <span className="text-base text-gray-600">Sim 4G:</span>
                        <span className="text-base font-medium text-gray-800">
                          {additionalServices.sim.toLocaleString()}₫
                        </span>
                      </div>
                    )}
                    {additionalServices.guide > 0 && (
                      <div className="flex justify-between">
                        <span className="text-base text-gray-600">Hướng dẫn viên:</span>
                        <span className="text-base font-medium text-gray-800">
                          {additionalServices.guide.toLocaleString()}₫
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between items-center font-bold mt-3">
                      <span className="text-lg">Tổng tiền:</span>
                      <span className="text-xl text-primary">{finalTotal.toLocaleString()}₫</span>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Đã bao gồm thuế và phí</p>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">
                    Thông tin di chuyển & lưu trú
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-semibold text-gray-600">Chiều đi:</p>
                      {transportationSummary && transportationSummary.depOption ? (
                        <div className="text-sm text-gray-600">
                          {transportationSummary.depOption.provider} -{" "}
                          {transportationSummary.depOption.departure_flight_number} (
                          {transportationSummary.depOption.departure_time} -{" "}
                          {transportationSummary.depOption.departure_arrival_time || "Chưa xác định"})
                        </div>
                      ) : (
                        <p className="text-sm text-gray-600">Chưa có thông tin chiều đi.</p>
                      )}
                      <p className="text-sm text-gray-600">
                        <span className="font-semibold">Hành lý:</span>{" "}
                        {transportationSummary && transportationSummary.depOption
                          ? transportationSummary.depOption.departure_baggage || "Chưa xác định"
                          : ""}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-600">Chiều về:</p>
                      {transportationSummary && transportationSummary.retOption ? (
                        <div className="text-sm text-gray-600">
                          {transportationSummary.retOption.provider} -{" "}
                          {transportationSummary.retOption.return_flight_number} (
                          {transportationSummary.retOption.return_time} -{" "}
                          {transportationSummary.retOption.return_arrival_time || "Chưa xác định"})
                        </div>
                      ) : (
                        <p className="text-sm text-gray-600">Chưa có thông tin chiều về.</p>
                      )}
                      <p className="text-sm text-gray-600">
                        <span className="font-semibold">Hành lý:</span>{" "}
                        {transportationSummary && transportationSummary.retOption
                          ? transportationSummary.retOption.return_baggage || "Chưa xác định"
                          : ""}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-600">Lưu trú:</p>
                      {accommodationsSummary && accommodationsSummary.length > 0 ? (
                        accommodationsSummary.map((accom: any) => (
                          <div key={accom.id} className="mb-2 text-sm text-gray-600">
                            <div>
                              {accom.name} - {accom.address}
                            </div>
                            <div>
                              Nhận phòng:{" "}
                              {accom.checkIn
                                ? formatDate(accom.checkIn)
                                : tripData.start_date
                                ? formatDate(tripData.start_date)
                                : "Chưa xác định"}{" "}
                              | Trả phòng:{" "}
                              {accom.checkOut
                                ? formatDate(accom.checkOut)
                                : tripData.end_date
                                ? formatDate(tripData.end_date)
                                : "Chưa xác định"}
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-600">Chưa có thông tin lưu trú.</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">Tóm tắt chuyến đi</h3>
                  <div className="space-y-4">
                    {getTripDays().map((day, index) => {
                      const dayAttractions = tripData.selectedAttractions?.filter(
                        (attr: any) => attr.day === index + 1
                      ) || [];
                      return (
                        <div key={index}>
                          <p className="text-sm font-semibold text-gray-600">
                            Ngày {formatDate(day)}:
                          </p>
                          {dayAttractions.length > 0 ? (
                            dayAttractions.map((attr: any) => {
                              const attractionDetails = Array.isArray(attractions)
                                ? attractions.find((a: Attraction) => a.id === attr.attractionId)
                                : null;
                              const childrenHeightSummary = attr.childrenHeights?.reduce(
                                (acc: { [key: string]: number }, height: string) => {
                                  acc[height] = (acc[height] || 0) + 1;
                                  return acc;
                                },
                                {}
                              );
                              const childrenHeightText = Object.entries(childrenHeightSummary || {})
                                .map(([height, count]) => `${count} trẻ em (${height})`)
                                .join(", ");
                              return attractionDetails ? (
                                <p key={attr.attractionId} className="text-sm text-gray-600">
                                  {attractionDetails.name} x {attr.adults} người lớn
                                  {attr.children > 0 && ` + ${childrenHeightText}`}
                                </p>
                              ) : (
                                <p key={attr.attractionId} className="text-sm text-gray-600">
                                  Điểm tham quan ID {attr.attractionId} (Chưa tải chi tiết)
                                </p>
                              );
                            })
                          ) : (
                            <p className="text-sm text-gray-600">Không tham quan</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <div className="flex justify-between p-6 pt-0">
        <Button variant="outline" onClick={handleBack} className="px-4 py-2">
          <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          Quay lại
        </Button>
        <Button
          onClick={form.handleSubmit(onSubmit)}
          className="bg-primary hover:bg-blue-700 text-white px-6 py-2"
        >
          Tiếp tục đến thanh toán
          <svg className="w-5 h-5 ml-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 6L15 12L9 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </Button>
      </div>
    </div>
  );
}